# BuildMyCV — Full-Stack Resume Studio (Frontend + Backend)

Is package mein **BuildMyCV** ka complete **Frontend (`public/index.html`)** aur **2 Ready-to-Run Backends** (`Node.js Express` + `Python Flask SQLite`) diye gaye hain.

---

## 🌟 Backend Kya Karta Hai?
1. **Cross-Device ₹11 UPI Verification**: Jab koi user apne phone se ₹11 UPI pay karke **12-digit UTR number** submit karta hai (`POST /api/payments`), toh woh seedhe server database mein save hota hai.
2. **Real-Time Admin Approval**: Jab aap apne PC ya phone se **Admin Panel** (`PIN: 1234`) khol kar **✓ Approve** click karte hain (`PATCH /api/admin/payments/:id`), toh user ke phone par **automatically PDF & HD JPG download unlock** ho jata hai!
3. **100% Secure Secrets**: Admin PIN aur Master Unlock Code frontend HTML mein chhupane ki jagah backend server (`/api/admin/login` & `/api/payments/verify-code`) par verify hote hain.
4. **Cloud Resume Save**: Users apna resume JSON server par bhi save kar sakte hain (`/api/resumes/save`).

---

## 🚀 Option 1: Node.js Backend Kaise Chalayein (`server.js`)

```bash
# 1. Folder ke andar jayein
cd BuildMyCV_FullStack

# 2. Packages install karein
npm install

# 3. Server start karein
npm start
```
Ab browser mein kholein: **`http://localhost:3000`**

---

## 🐍 Option 2: Python Flask + SQLite Backend Kaise Chalayein (`app.py`)

Agar aap Python pasand karte hain, toh bina Node.js ke seedhe `app.py` chala sakte hain:

```bash
# 1. Flask install karein
pip install -r requirements.txt

# 2. Server start karein
python app.py
```
Ab browser mein kholein: **`http://localhost:3000`** (SQLite database `data/buildmycv.db` apne aap ban jayega).

---

## ☁️ Free Online Hosting (Render / Railway / VPS) Par Kaise Deploy Karein?

1. Is poore folder ko apne **GitHub repository** par upload karein.
2. **Render.com** ya **Railway.app** par जाकर **"New Web Service"** chunein aur apna GitHub repo connect karein.
3. Render `render.yaml` ko automatically detect kar lega (`Build Command: npm install`, `Start Command: npm start`).
4. Deploy hote hi aapki live website + backend ready ho jayegi!
5. Agar aap frontend (`BuildMyCV.html`) ko Netlify/Vercel/GitHub Pages par alag se host karte hain, toh **Admin Panel → 🌐 Backend API URL** mein apne Render backend ka URL daal kar connect kar sakte hain.

---

## 📡 REST API Endpoints Reference

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/health` | Check server status & engine |
| `GET` | `/api/settings` | Get public UPI ID, Merchant Name, Price (`₹11`) & Free Mode |
| `POST` | `/api/payments` | Submit new ₹11 UPI UTR verification request |
| `GET` | `/api/payments/status/:idOrUtr` | Poll live approval status by Request ID (`BMCV-XXXX`) or 12-digit UTR |
| `POST` | `/api/payments/verify-code` | Verify Master Unlock Code or approved UTR on server |
| `POST` | `/api/admin/login` | Authenticate Admin PIN and get Bearer token |
| `GET` | `/api/admin/payments` | List all payment requests & revenue KPIs (Admin Protected) |
| `PATCH` | `/api/admin/payments/:id` | Approve or Reject a payment request (Admin Protected) |
| `POST` | `/api/admin/payments/approve-all` | Approve all pending requests at once (Admin Protected) |
| `DELETE` | `/api/admin/payments/:id` | Delete a payment request (Admin Protected) |
| `PUT` | `/api/admin/settings` | Update UPI ID, Merchant Name, Price, Unlock Code & Admin PIN |
