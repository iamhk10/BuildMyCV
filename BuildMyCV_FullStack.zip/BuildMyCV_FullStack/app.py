"""
BuildMyCV — Production Backend Server (Python Flask + SQLite)
Run with:
    pip install -r requirements.txt
    python app.py
"""

import os
import json
import hmac
import hashlib
import random
import sqlite3
from datetime import datetime
from functools import wraps
from flask import Flask, request, jsonify, send_from_directory

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
DB_PATH = os.path.join(DATA_DIR, 'buildmycv.db')
os.makedirs(DATA_DIR, exist_ok=True)

app = Flask(__name__, static_folder='public', static_url_path='')
ADMIN_SECRET = os.environ.get('ADMIN_SECRET', 'buildmycv-secret-key-2026')


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            upi_id TEXT NOT NULL,
            merchant_name TEXT NOT NULL,
            price INTEGER NOT NULL,
            unlock_code TEXT NOT NULL,
            admin_pin TEXT NOT NULL,
            free_mode INTEGER NOT NULL DEFAULT 0
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS payments (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            utr TEXT NOT NULL,
            amount INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            time TEXT NOT NULL,
            proof TEXT DEFAULT '',
            proof_data TEXT DEFAULT ''
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS resumes (
            share_id TEXT PRIMARY KEY,
            updated_at TEXT NOT NULL,
            resume_json TEXT NOT NULL
        )
    """)
    cur.execute("SELECT COUNT(*) as cnt FROM settings WHERE id = 1")
    if cur.fetchone()['cnt'] == 0:
        cur.execute("""
            INSERT INTO settings (id, upi_id, merchant_name, price, unlock_code, admin_pin, free_mode)
            VALUES (1, ?, ?, ?, ?, ?, 0)
        """, (
            os.environ.get('UPI_ID', 'buildmycv@upi'),
            os.environ.get('MERCHANT_NAME', 'BuildMyCV Studio'),
            int(os.environ.get('PRICE_INR', 11)),
            os.environ.get('MASTER_UNLOCK_CODE', 'BMCV11'),
            os.environ.get('ADMIN_PIN', '1234')
        ))
    cur.execute("SELECT COUNT(*) as cnt FROM payments")
    if cur.fetchone()['cnt'] == 0:
        cur.execute("""
            INSERT INTO payments (id, name, phone, utr, amount, status, time, proof)
            VALUES
            ('BMCV-9041', 'Aarav Sharma', '+91 98765 11220', '412890341289', 11, 'approved', '16/10/2026, 6:20:00 pm', ''),
            ('BMCV-9042', 'Neha Gupta', '+91 91234 55678', '412899874512', 11, 'pending', '16/10/2026, 9:45:00 pm', '')
        """)
    conn.commit()
    conn.close()


init_db()


def make_token(pin: str) -> str:
    return hmac.new(ADMIN_SECRET.encode(), str(pin).encode(), hashlib.sha256).hexdigest()


def get_settings_dict():
    conn = get_db()
    row = conn.execute("SELECT * FROM settings WHERE id = 1").fetchone()
    conn.close()
    return {
        'upiId': row['upi_id'],
        'merchantName': row['merchant_name'],
        'price': row['price'],
        'unlockCode': row['unlock_code'],
        'adminPin': row['admin_pin'],
        'freeMode': bool(row['free_mode'])
    }


def require_admin(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        s = get_settings_dict()
        auth = request.headers.get('Authorization', '').replace('Bearer ', '').strip()
        pin_hdr = request.headers.get('X-Admin-Pin', '').strip()
        if auth == make_token(s['adminPin']) or pin_hdr == s['adminPin']:
            return fn(*args, **kwargs)
        return jsonify({'error': 'Unauthorized: Invalid Admin PIN or Token'}), 401
    return wrapper


@app.after_request
def add_cors(resp):
    resp.headers['Access-Control-Allow-Origin'] = '*'
    resp.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-Admin-Pin'
    resp.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, PATCH, DELETE, OPTIONS'
    return resp


@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({'ok': True, 'service': 'BuildMyCV Backend API', 'engine': 'Python Flask + SQLite'})


@app.route('/api/settings', methods=['GET'])
def public_settings():
    s = get_settings_dict()
    return jsonify({
        'upiId': s['upiId'],
        'merchantName': s['merchantName'],
        'price': s['price'],
        'freeMode': s['freeMode']
    })


@app.route('/api/payments', methods=['POST'])
def create_payment():
    data = request.get_json(silent=True) or {}
    name = str(data.get('name', '')).strip()
    phone = str(data.get('phone', '')).strip()
    utr = str(data.get('utr', '')).strip()
    proof = str(data.get('proof', '')).strip()

    if not name or not phone or len(utr) < 8:
        return jsonify({'error': 'Name, Phone, and valid 12-digit UTR are required.'}), 400

    s = get_settings_dict()
    conn = get_db()
    existing = conn.execute("SELECT * FROM payments WHERE utr = ?", (utr,)).fetchone()
    if existing:
        conn.close()
        return jsonify({
            'ok': True,
            'duplicate': True,
            'request': dict(existing)
        })

    req_id = f"BMCV-{random.randint(1000, 9999)}"
    now_str = datetime.now().strftime('%d/%m/%Y, %I:%M:%S %p')
    conn.execute("""
        INSERT INTO payments (id, name, phone, utr, amount, status, time, proof, proof_data)
        VALUES (?, ?, ?, ?, ?, 'pending', ?, ?, ?)
    """, (req_id, name, phone, utr, s['price'], now_str, 'Screenshot Attached' if proof else '', proof))
    conn.commit()
    conn.close()

    return jsonify({
        'ok': True,
        'request': {
            'id': req_id,
            'name': name,
            'phone': phone,
            'utr': utr,
            'amount': s['price'],
            'status': 'pending',
            'time': now_str,
            'proof': 'Screenshot Attached' if proof else ''
        }
    }), 201


@app.route('/api/payments/status/<id_or_utr>', methods=['GET'])
def payment_status(id_or_utr):
    key = id_or_utr.strip().upper()
    s = get_settings_dict()
    if s['freeMode']:
        return jsonify({'ok': True, 'unlocked': True, 'status': 'approved', 'freeMode': True})
    conn = get_db()
    row = conn.execute(
        "SELECT id, name, phone, utr, amount, status, time, proof FROM payments WHERE UPPER(id) = ? OR UPPER(utr) = ?",
        (key, key)
    ).fetchone()
    conn.close()
    if not row:
        return jsonify({'ok': False, 'error': 'Payment request not found'}), 404
    d = dict(row)
    return jsonify({'ok': True, 'unlocked': d['status'] == 'approved', 'status': d['status'], 'request': d})


@app.route('/api/payments/verify-code', methods=['POST'])
def verify_code():
    data = request.get_json(silent=True) or {}
    code = str(data.get('code', '')).strip().upper()
    s = get_settings_dict()
    if code and code == s['unlockCode'].upper():
        return jsonify({'ok': True, 'unlocked': True, 'mode': 'master_code'})
    conn = get_db()
    row = conn.execute(
        "SELECT id, status FROM payments WHERE (UPPER(utr) = ? OR UPPER(id) = ?) AND status = 'approved'",
        (code, code)
    ).fetchone()
    conn.close()
    if row:
        return jsonify({'ok': True, 'unlocked': True, 'mode': 'approved_utr'})
    return jsonify({'ok': False, 'unlocked': False, 'error': 'Invalid code or unapproved UTR'}), 403


@app.route('/api/admin/login', methods=['POST'])
def admin_login():
    data = request.get_json(silent=True) or {}
    pin = str(data.get('pin', '')).strip()
    s = get_settings_dict()
    if pin == s['adminPin']:
        return jsonify({'ok': True, 'token': make_token(s['adminPin']), 'settings': s})
    return jsonify({'ok': False, 'error': 'Incorrect Admin PIN'}), 401


@app.route('/api/admin/payments', methods=['GET'])
@require_admin
def admin_list_payments():
    s = get_settings_dict()
    conn = get_db()
    rows = [dict(r) for r in conn.execute("SELECT id, name, phone, utr, amount, status, time, proof FROM payments ORDER BY rowid DESC").fetchall()]
    conn.close()
    total = len(rows)
    pending = sum(1 for r in rows if r['status'] == 'pending')
    approved = sum(1 for r in rows if r['status'] == 'approved')
    revenue = sum(int(r['amount'] or s['price']) for r in rows if r['status'] == 'approved')
    return jsonify({'ok': True, 'kpis': {'total': total, 'pending': pending, 'approved': approved, 'revenue': revenue}, 'settings': s, 'payments': rows})


@app.route('/api/admin/payments/<req_id>', methods=['PATCH'])
@require_admin
def admin_update_payment(req_id):
    data = request.get_json(silent=True) or {}
    status = data.get('status')
    if status not in ('approved', 'rejected', 'pending'):
        return jsonify({'error': 'Invalid status'}), 400
    conn = get_db()
    conn.execute("UPDATE payments SET status = ? WHERE id = ?", (status, req_id))
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': req_id, 'status': status})


@app.route('/api/admin/payments/approve-all', methods=['POST'])
@require_admin
def admin_approve_all():
    conn = get_db()
    conn.execute("UPDATE payments SET status = 'approved' WHERE status = 'pending'")
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@app.route('/api/admin/payments/<req_id>', methods=['DELETE'])
@require_admin
def admin_delete_payment(req_id):
    conn = get_db()
    conn.execute("DELETE FROM payments WHERE id = ?", (req_id,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@app.route('/api/admin/settings', methods=['PUT'])
@require_admin
def admin_save_settings():
    data = request.get_json(silent=True) or {}
    s = get_settings_dict()
    upi_id = str(data.get('upiId', s['upiId'])).strip()
    merchant = str(data.get('merchantName', s['merchantName'])).strip()
    price = int(data.get('price', s['price']) or 11)
    unlock_code = str(data.get('unlockCode', s['unlockCode'])).strip()
    admin_pin = str(data.get('adminPin', s['adminPin'])).strip()
    free_mode = 1 if data.get('freeMode') else 0

    conn = get_db()
    conn.execute("""
        UPDATE settings
        SET upi_id = ?, merchant_name = ?, price = ?, unlock_code = ?, admin_pin = ?, free_mode = ?
        WHERE id = 1
    """, (upi_id, merchant, price, unlock_code, admin_pin, free_mode))
    conn.commit()
    conn.close()
    new_s = get_settings_dict()
    return jsonify({'ok': True, 'settings': new_s, 'token': make_token(new_s['adminPin'])})


@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_spa(path):
    full_path = os.path.join(BASE_DIR, 'public', path)
    if path and os.path.exists(full_path):
        return send_from_directory('public', path)
    return send_from_directory('public', 'index.html')


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 3000))
    print(f"🚀 BuildMyCV Python Flask Backend running on http://localhost:{port}")
    app.run(host='0.0.0.0', port=port, debug=False)
