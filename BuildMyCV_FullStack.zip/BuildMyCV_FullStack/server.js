/**
 * BuildMyCV — Production Backend Server (Node.js + Express)
 * Supports:
 *  - ₹11 UPI Payment Request Submission & UTR Duplicate Check
 *  - Real-time Payment Status Polling across devices (User Phone -> Admin PC)
 *  - Server-side Admin PIN Authentication & Bearer Token Security
 *  - Admin Approve / Reject / Delete & CSV Export
 *  - UPI ID, Merchant Name, Price & Free-Mode Configuration
 *  - Cloud Resume Save & Shareable Link API
 *  - Zero External AI API Keys Required
 */

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'database.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Initialize Default Database State
const DEFAULT_DB = {
  settings: {
    upiId: process.env.UPI_ID || 'buildmycv@upi',
    merchantName: process.env.MERCHANT_NAME || 'BuildMyCV Studio',
    price: Number(process.env.PRICE_INR || 11),
    unlockCode: process.env.MASTER_UNLOCK_CODE || 'BMCV11',
    adminPin: process.env.ADMIN_PIN || '1234',
    freeMode: false
  },
  payments: [
    {
      id: 'BMCV-9041',
      name: 'Aarav Sharma',
      phone: '+91 98765 11220',
      utr: '412890341289',
      amount: 11,
      status: 'approved',
      time: '16/10/2026, 6:20:00 pm',
      proof: ''
    },
    {
      id: 'BMCV-9042',
      name: 'Neha Gupta',
      phone: '+91 91234 55678',
      utr: '412899874512',
      amount: 11,
      status: 'pending',
      time: '16/10/2026, 9:45:00 pm',
      proof: ''
    }
  ],
  resumes: {}
};

function readDb() {
  try {
    if (!fs.existsSync(DB_FILE)) {
      fs.writeFileSync(DB_FILE, JSON.stringify(DEFAULT_DB, null, 2), 'utf8');
      return JSON.parse(JSON.stringify(DEFAULT_DB));
    }
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } catch (err) {
    console.error('Database read error:', err);
    return JSON.parse(JSON.stringify(DEFAULT_DB));
  }
}

function writeDb(data) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    console.error('Database write error:', err);
  }
}

// Active Admin Session Tokens (in-memory + stateless HMAC fallback)
const ADMIN_SECRET = process.env.ADMIN_SECRET || 'buildmycv-secret-key-2026';
function createAdminToken(pin) {
  return crypto.createHmac('sha256', ADMIN_SECRET).update(String(pin)).digest('hex');
}

function requireAdmin(req, res, next) {
  const db = readDb();
  const authHeader = req.headers.authorization || '';
  const token = authHeader.replace(/^Bearer\s+/i, '').trim();
  const pinHeader = req.headers['x-admin-pin'] || '';
  const validToken = createAdminToken(db.settings.adminPin);

  if (token === validToken || pinHeader === db.settings.adminPin) {
    return next();
  }
  return res.status(401).json({ error: 'Unauthorized: Invalid Admin PIN or Token' });
}

// -------------------------------------------------------------------------
// PUBLIC API ENDPOINTS
// -------------------------------------------------------------------------

// 1. Health Check
app.get('/api/health', (req, res) => {
  res.json({
    ok: true,
    service: 'BuildMyCV Backend API',
    engine: 'Node.js + Express',
    timestamp: new Date().toISOString()
  });
});

// 2. Get Public UPI & Pricing Settings (Hides Admin PIN & Unlock Code!)
app.get('/api/settings', (req, res) => {
  const db = readDb();
  res.json({
    upiId: db.settings.upiId,
    merchantName: db.settings.merchantName,
    price: db.settings.price,
    freeMode: Boolean(db.settings.freeMode)
  });
});

// 3. Submit a ₹11 UPI Payment Request
app.post('/api/payments', (req, res) => {
  const { name, phone, utr, proof } = req.body || {};
  const cleanName = String(name || '').trim();
  const cleanPhone = String(phone || '').trim();
  const cleanUtr = String(utr || '').trim();

  if (!cleanName || !cleanPhone || cleanUtr.length < 8) {
    return res.status(400).json({ error: 'Name, Phone, and valid 12-digit UTR number are required.' });
  }

  const db = readDb();
  const existing = db.payments.find(p => p.utr === cleanUtr);
  if (existing) {
    return res.json({
      ok: true,
      duplicate: true,
      message: 'This UTR is already registered. Returning current status.',
      request: existing
    });
  }

  const newReq = {
    id: 'BMCV-' + Math.floor(1000 + Math.random() * 9000),
    name: cleanName,
    phone: cleanPhone,
    utr: cleanUtr,
    amount: db.settings.price || 11,
    status: 'pending',
    time: new Date().toLocaleString('en-IN'),
    proof: proof ? 'Screenshot Attached' : '',
    proofData: proof || ''
  };

  db.payments.unshift(newReq);
  writeDb(db);

  res.status(201).json({
    ok: true,
    message: 'Payment request submitted for Admin verification.',
    request: {
      id: newReq.id,
      name: newReq.name,
      phone: newReq.phone,
      utr: newReq.utr,
      amount: newReq.amount,
      status: newReq.status,
      time: newReq.time,
      proof: newReq.proof
    }
  });
});

// 4. Check Payment Status by Request ID or UTR Number
app.get('/api/payments/status/:idOrUtr', (req, res) => {
  const key = String(req.params.idOrUtr || '').trim().toUpperCase();
  const db = readDb();
  if (db.settings.freeMode) {
    return res.json({ ok: true, unlocked: true, status: 'approved', freeMode: true });
  }
  const found = db.payments.find(
    p => p.id.toUpperCase() === key || String(p.utr).toUpperCase() === key
  );
  if (!found) {
    return res.status(404).json({ ok: false, error: 'Payment request not found.' });
  }
  res.json({
    ok: true,
    unlocked: found.status === 'approved',
    status: found.status,
    request: {
      id: found.id,
      name: found.name,
      utr: found.utr,
      amount: found.amount,
      status: found.status,
      time: found.time
    }
  });
});

// 5. Verify Master Unlock Code or Approved UTR (Server-Side)
app.post('/api/payments/verify-code', (req, res) => {
  const code = String((req.body && req.body.code) || '').trim();
  const db = readDb();
  if (!code) {
    return res.status(400).json({ ok: false, unlocked: false, error: 'Code is required' });
  }
  if (code.toUpperCase() === String(db.settings.unlockCode).toUpperCase()) {
    return res.json({ ok: true, unlocked: true, mode: 'master_code' });
  }
  const approvedUtr = db.payments.find(
    p => (String(p.utr).toUpperCase() === code.toUpperCase() || p.id.toUpperCase() === code.toUpperCase()) && p.status === 'approved'
  );
  if (approvedUtr) {
    return res.json({ ok: true, unlocked: true, mode: 'approved_utr', request: approvedUtr });
  }
  return res.status(403).json({ ok: false, unlocked: false, error: 'Invalid unlock code or unapproved UTR.' });
});

// 6. Save & Load Cloud Resume JSON (Optional Cloud Sync)
app.post('/api/resumes/save', (req, res) => {
  const resumeData = req.body && req.body.resume;
  if (!resumeData) return res.status(400).json({ error: 'Missing resume payload' });
  const db = readDb();
  const shareId = (req.body.shareId || ('CV-' + crypto.randomBytes(3).toString('hex').toUpperCase()));
  db.resumes[shareId] = {
    shareId,
    updatedAt: new Date().toISOString(),
    resume: resumeData
  };
  writeDb(db);
  res.json({ ok: true, shareId, updatedAt: db.resumes[shareId].updatedAt });
});

app.get('/api/resumes/:shareId', (req, res) => {
  const db = readDb();
  const item = db.resumes[req.params.shareId];
  if (!item) return res.status(404).json({ error: 'Resume not found' });
  res.json({ ok: true, data: item });
});

// -------------------------------------------------------------------------
// PROTECTED ADMIN API ENDPOINTS
// -------------------------------------------------------------------------

// 7. Admin Login
app.post('/api/admin/login', (req, res) => {
  const pin = String((req.body && req.body.pin) || '').trim();
  const db = readDb();
  if (pin === String(db.settings.adminPin)) {
    return res.json({
      ok: true,
      token: createAdminToken(db.settings.adminPin),
      settings: db.settings
    });
  }
  return res.status(401).json({ ok: false, error: 'Incorrect Admin PIN' });
});

// 8. Admin Get All Payments & KPIs
app.get('/api/admin/payments', requireAdmin, (req, res) => {
  const db = readDb();
  const total = db.payments.length;
  const pending = db.payments.filter(p => p.status === 'pending').length;
  const approved = db.payments.filter(p => p.status === 'approved').length;
  const revenue = db.payments
    .filter(p => p.status === 'approved')
    .reduce((sum, p) => sum + (Number(p.amount) || db.settings.price || 11), 0);

  res.json({
    ok: true,
    kpis: { total, pending, approved, revenue },
    settings: db.settings,
    payments: db.payments
  });
});

// 9. Admin Approve or Reject Single Payment Request
app.patch('/api/admin/payments/:id', requireAdmin, (req, res) => {
  const reqId = req.params.id;
  const { status } = req.body || {};
  if (!['approved', 'rejected', 'pending'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status value' });
  }
  const db = readDb();
  const idx = db.payments.findIndex(p => p.id === reqId);
  if (idx === -1) return res.status(404).json({ error: 'Payment request not found' });

  db.payments[idx].status = status;
  writeDb(db);
  res.json({ ok: true, request: db.payments[idx] });
});

// 10. Admin Approve All Pending Requests
app.post('/api/admin/payments/approve-all', requireAdmin, (req, res) => {
  const db = readDb();
  let count = 0;
  db.payments = db.payments.map(p => {
    if (p.status === 'pending') {
      count++;
      return Object.assign({}, p, { status: 'approved' });
    }
    return p;
  });
  writeDb(db);
  res.json({ ok: true, approvedCount: count, payments: db.payments });
});

// 11. Admin Delete Payment Request
app.delete('/api/admin/payments/:id', requireAdmin, (req, res) => {
  const db = readDb();
  db.payments = db.payments.filter(p => p.id !== req.params.id);
  writeDb(db);
  res.json({ ok: true });
});

// 12. Admin Update Gateway & Pricing Settings
app.put('/api/admin/settings', requireAdmin, (req, res) => {
  const db = readDb();
  const body = req.body || {};
  db.settings = {
    upiId: String(body.upiId || db.settings.upiId).trim(),
    merchantName: String(body.merchantName || db.settings.merchantName).trim(),
    price: Number(body.price || db.settings.price || 11),
    unlockCode: String(body.unlockCode || db.settings.unlockCode).trim(),
    adminPin: String(body.adminPin || db.settings.adminPin).trim(),
    freeMode: Boolean(body.freeMode)
  };
  writeDb(db);
  res.json({
    ok: true,
    settings: db.settings,
    token: createAdminToken(db.settings.adminPin)
  });
});

// Fallback to Frontend SPA (public/index.html)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`\n🚀 BuildMyCV Full-Stack Server running at: http://localhost:${PORT}`);
  console.log(`🔐 Admin Panel Default PIN: ${readDb().settings.adminPin}`);
  console.log(`💳 UPI ID Configured: ${readDb().settings.upiId}\n`);
});
